const express = require('express')
const app = express()

app.get('/', (req, res) => {
	res.send('Please change URI. This is the main root.')
})

app.get('/burgers', (req, res) => {
    res.send('Order your Burger and Fries today!')
})
app.get('/nachos', (req, res) => {
    res.send('Order your Nachos Today!')
})

app.get('/burgers/:burger/fries/:fries', function (req, res) {
	//get params
	//res.send('test')
	var burgers= parseInt(req.params['burger'])
	var fries=parseInt(req.params['fries'])

	var message;
	if (burgers < fries || fries < burgers) {
		message = "The number of burgers "+burgers+" is not equal to the number of " + fries +" fries."+ " Would you like to order again?"
		res.send(message)
	}
	else {message=" Your order "+burgers+" burgers"+" and"+fries+" fries "+ "is equal amounts"}
	res.send(message)
})

//nachos
app.get('/nachos/:nachos/salsa/:salsa/cheese/:cheese/sourcream/:sourcream/hot/:hot', function (req, res) {
	//get params. Use yes or no for all other toppings except nachos which requires a number
	var nachos = parseInt(req.params['nachos'])
	var salsa =(req.params['salsa'])
	var cheese=(req.params['cheese'])
	var sourcream=(req.params['sourcream'])
	var hot=(req.params['hot'])

	res.send("There are "+nachos+" nachos "+salsa+" salsa "+cheese+" cheese "+sourcream+" sourcream "+hot+" hot ")
})

app.listen(8080, () => console.log('express_app is running on port 8080'))