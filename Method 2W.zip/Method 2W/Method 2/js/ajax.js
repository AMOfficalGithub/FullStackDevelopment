/*Using AJAX/Vanilla Javascript*/
function loadAJAX() {
  //[1] make a new request object
  var xhttp = new XMLHttpRequest();

  //[2] set the request options
  xhttp.open("GET", "data/Holder.json", true);

  //[3] define what you will do when you ge a response (callback)
  xhttp.onreadystatechange = function(){
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("vanilla_ajax").innerHTML = this.responseText;
    }
  };

  //[4] finally send out the request
  xhttp.send();
}

function loadJQUERY(){
  /*place holder for ajax loading using JQuery*/
  $('#jq_ajax').append('<p id = "test">'); //jq test
  $.ajax({
      url: "data/Holder.json",
      type: 'GET',
      dataType: "json",
    success: function (result) {
      $("#jq_ajax").html("<p>" + result.data +"&nbsp;"+ result.data2+ "</p>");
    }
  });
}

