var express = require('express') //needed. install this
var cookieParser = require('cookie-parser') //install this
var app = express()

app.use(cookieParser())

//set cookie
app.get('/:number', function(req, res){
    var number=parseInt(req.params['number']);
    res.cookie('TimedCookie','number',{maxAge: 600000}).send('Cookie expiration is set as '+number);
    //or
   //res.cookie('TimedCookie','number', {expire: 400000 + Date.now()});
})

app.listen(8080, () => console.log('cookie app listening on port 8080!'))